package servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import service.SenorSmService;

import model.CategoriaBean;
import dao.CategoriaDao;
import dao.ImagenDao;
import dao.MarcaDao;
import dao.ProductoDao;
import java.io.File;
import java.io.PrintWriter;
import java.util.Iterator;
import javax.servlet.http.HttpSession;
import model.ImagenBean;
import model.MarcaBean;
import model.ProductoBean;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

@WebServlet({"/AddProducto", "/AddCategoria", "/AddMarca", "/Usuario", "/Main"})
public class SenorSmController extends HttpServlet {

    private SenorSmService es;
    private static final long serialVersionUID = 1L;
    private static final String DATA_DIRECTORY = "data";
    private static final int MAX_MEMORY_SIZE = 1024 * 1024 * 2;
    private static final int MAX_REQUEST_SIZE = 1024 * 1024;
    private String fileName ="";
    @Override
    public void init() throws ServletException {
        es = new SenorSmService();
    }

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String path = request.getServletPath();
        if (path.equals("/AddProducto")) {
            addProducto(request, response);
        } else if (path.equals("/AddCategoria")) {
            addCategoria(request, response);
        } else if (path.equals("/AddMarca")) {
            addMarca(request, response);
        } else if (path.equals("/Usuario")) {
            Usuario(request, response);
        } else if (path.equals("/Main")) {
            Listado(request, response);
        }

    }

    private void addProducto(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //imagen
        boolean isMultipart = ServletFileUpload.isMultipartContent(request);

        if (!isMultipart) {
            return;
        }
        DiskFileItemFactory factory = new DiskFileItemFactory();
        factory.setSizeThreshold(MAX_MEMORY_SIZE);
        factory.setRepository(new File(System.getProperty("java.io.tmpdir")));
        String uploadFolder = getServletContext().getRealPath("") + File.separator + DATA_DIRECTORY;
        ServletFileUpload upload = new ServletFileUpload(factory);
        upload.setSizeMax(MAX_REQUEST_SIZE);
        try {
            //Imagen
            List items = upload.parseRequest(request);
            Iterator iter = items.iterator();
            while (iter.hasNext()) {
                FileItem item = (FileItem) iter.next();
                if (!item.isFormField()) {
                    fileName = new File(item.getName()).getName();
                    request.setAttribute("file", DATA_DIRECTORY + File.separator + fileName);
                    String filePath = uploadFolder + File.separator + fileName;
                    File uploadedFile = new File(filePath);
                    System.out.println(filePath);
                    item.write(uploadedFile);
                   // es.addImagen(fileName);
                }
            }
            // Datos
            //int idcat = Integer.parseInt(request.getParameter("idcat"));
            //int idmar = Integer.parseInt(request.getParameter("idmar"));
            String nombre = request.getParameter("nombre");
            /*Double preciocompra = Double.parseDouble(request.getParameter("preciocompra"));
            Double precioventa = Double.parseDouble(request.getParameter("precioventa"));
            int stock = Integer.parseInt(request.getParameter("stock"));
            es.addProducto(idcat, idmar, nombre, preciocompra, precioventa, stock, fileName);*/
            
            
            int idcat = 1;
            int idmar = 1;
            //String nombre = "Hola";
            Double preciocompra = 3.0;
            Double precioventa = 3.0;
            int stock = 3;
            fileName = "juan.jpg";
            
            es.addProducto(idcat, idmar, nombre, preciocompra, precioventa, stock, fileName);
            Listado(request, response);
            // Salida
            request.setAttribute("msg", "Proceso ok.");
        } catch (FileUploadException ex) {
            throw new ServletException(ex);
        } catch (Exception ex) {
            throw new ServletException(ex);
        }

        // Forward
        RequestDispatcher rd;
        rd = request.getRequestDispatcher("articulo.jsp");
        rd.forward(request, response);
    }

    private void addCategoria(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {

            // Datos
            String nombre = request.getParameter("nombre");
            // Proceso
            es.addCategoria(nombre);
            Listado(request, response);
            // Salida
            request.setAttribute("msg", "Proceso ok.");
        } catch (Exception e) {
            request.setAttribute("error", e.getMessage());
        }

        // Forward
        RequestDispatcher rd;
        rd = request.getRequestDispatcher("articulo.jsp");
        rd.forward(request, response);
    }


    private void addMarca(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Datos
            String nombre = request.getParameter("nombre");
            // Proceso
            es.addMarca(nombre);
            Listado(request, response);
            // Salida
            request.setAttribute("msg", "Proceso ok.");
        } catch (Exception e) {
            request.setAttribute("error", e.getMessage());
        }

        // Forward
        RequestDispatcher rd;
        rd = request.getRequestDispatcher("articulo.jsp");
        rd.forward(request, response);
    }

    private void Listado(HttpServletRequest request, HttpServletResponse response) {
        try {

            CategoriaDao tcDao = new CategoriaDao();
            List<CategoriaBean> listaCategoria = new ArrayList<CategoriaBean>();
            listaCategoria = tcDao.listar();
            request.setAttribute("listaCategoria", listaCategoria);

            MarcaDao LMarca = new MarcaDao();
            List<MarcaBean> listaMarca = new ArrayList<MarcaBean>();
            listaMarca = LMarca.listar();
            request.setAttribute("listaMarca", listaMarca);

            ProductoDao LProducto = new ProductoDao();
            List<ProductoBean> listaProducto = new ArrayList<ProductoBean>();
            listaProducto = LProducto.listar();
            request.setAttribute("listaProducto", listaProducto);


            request.getRequestDispatcher("articulo.jsp").forward(request, response);
        } catch (Exception e) {
            request.setAttribute("error", e.getMessage());
        }
    }

    public void Usuario(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            HttpSession session = request.getSession();
            String sLogin = request.getParameter("txtLogin");
            String sPassword = request.getParameter("txt-password");
            if (sLogin == null) {
                sLogin = session.getAttribute("login").toString();
            }
            if (sPassword == null) {
                sPassword = session.getAttribute("password").toString();
            }

            if (sLogin.equals("admin") && sPassword.equals("123")) {
                session.setAttribute("login", sLogin);
                session.setAttribute("password", sPassword);

                Listado(request, response);

            } else {

            }

        }
    }

}
